import numpy as np
import pandas as pd

from sklearn.preprocessing import MinMaxScaler, StandardScaler, LabelEncoder
import joblib

from keras.models import Sequential, load_model
from keras.layers import *
from keras.utils.np_utils import to_categorical
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, CSVLogger

import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

examplefile = "example.csv"
modelfile = "propcap_model.h5"
scalerfilename = "scaler.save"
lendingccybasedratefile = "lendingccybasedrate.csv"
propertylocationratefile = "propertylocation.csv"
tenantconditionratefile = "tenantcondition.csv"
propertytyperatefile = "propertytype.csv"
otherfactorratefile = "otherfactor.csv"
nationalityratefile = "nationality.csv"
occupationratefile = "employmenttype.csv"
propertyconditionfile = "propertycondition.csv"
baseratefile = "base.csv"

#lvrlist = [0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8]
lvrlist = [0.7, 0.75, 0.8]

exampledata = pd.read_csv(examplefile, header = None)
X_example = pd.DataFrame(columns = exampledata.iloc[:,0].tolist())
for i in range(len(lvrlist)):
    X_example.loc[i,:] = exampledata.iloc[:,1].tolist()

lendingccybasedratedata = pd.read_csv(lendingccybasedratefile, header = 0)
nationalityratedata = pd.read_csv(nationalityratefile, header = 0)
propertylocationratedata = pd.read_csv(propertylocationratefile, header = 0)
tenantconditionratedata = pd.read_csv(tenantconditionratefile, header = 0)
propertytyperatedata = pd.read_csv(propertytyperatefile, header = 0)
occupationratedata = pd.read_csv(occupationratefile, header = 0)
otherfactorratedata = pd.read_csv(otherfactorratefile, header = 0)
baseratedata = pd.read_csv(baseratefile, header = 0)
propertyconditiondata = pd.read_csv(propertyconditionfile, header = 0)

X_example["TotalAnnualCommitmentsRatio"] = (X_example["Mortgage Expense"].astype(float) + X_example["Annuity & Rent Expense"].astype(float) + 1.1 * X_example["Loans Expense"].astype(float) + X_example["Household Expense"].astype(float) + X_example["Other Expense"].astype(float)) / X_example["Property Value"].astype(float)
X_example["TotalAnnualIncomeRatio"] = (0.9* X_example["Wages"].astype(float) + 0.8 * X_example["Interest & Dividends"].astype(float) + 0.9 * X_example["Partner Income"].astype(float) + 0.8 * X_example["Rental Income"].astype(float) + 0.7 * X_example["Investment Income"].astype(float) + 0.6 * X_example["Others Income"].astype(float)) / X_example["Property Value"].astype(float)
X_example["ProposedAnnualRentRatio"] = X_example["Proposed Annual Rent"].astype(float) / X_example["Property Value"].astype(float)
X_example["PropertyAssetsRatio"] = (0.3 * X_example["Real Estates"].astype(float)) / X_example["Property Value"].astype(float)
X_example["NonPropertyAssetsRatio"] = (X_example["Deposits"].astype(float) + 0.9 * X_example["Bonds"].astype(float) + 0.6 * X_example["Pensions"].astype(float) + 0.75 * X_example["Stocks & Fund"].astype(float) + 0.6 * X_example["Others Assets"].astype(float)) / X_example["Property Value"].astype(float)
X_example["TotalLiabilitiesRatio"] = (X_example["Personal Loans"].astype(float) + X_example["Car Loans"].astype(float) + X_example["Tax Loans"].astype(float) + X_example["Other Loans"].astype(float) + X_example["Mortgage Loans"].astype(float)) / X_example["Property Value"].astype(float)

X_example["LendingCCYBasedRate"] = np.nan
X_example["OtherFixFactorBasedRate"] = np.nan
X_example["BaseRate"] = baseratedata.iloc[0].values[0]
X_example["LVR"] = lvrlist

for i in range(len(X_example)):
    otherfixfactorbasedrate = 0

    lendingccybasedratelist = lendingccybasedratedata.loc[(lendingccybasedratedata["LendingCCY"] == X_example.loc[i, "Lending CCY"]) & (lendingccybasedratedata["LendingYieldCurve"].astype(float) == float(X_example.loc[i, "Lending Yield Curve"])), "LendingCCYBasedRate"].tolist()
    if len(lendingccybasedratelist) != 0:
        X_example.loc[i, "LendingCCYBasedRate"] = lendingccybasedratelist[0]
    else:
        X_example.loc[i, "LendingCCYBasedRate"] = max(lendingccybasedratedata["LendingCCYBasedRate"].tolist())

    nationalityratelist = nationalityratedata.loc[nationalityratedata["Nationality"] == X_example.loc[i, "Nationality"], "Spread"].tolist()
    if len(nationalityratelist) != 0:
        otherfixfactorbasedrate += nationalityratelist[0]
    else:
        otherfixfactorbasedrate += 0.005

    propertylocationratelist = propertylocationratedata.loc[((propertylocationratedata["Location"] == X_example.loc[i, "Property Location"]) & (propertylocationratedata["Country"] == X_example.loc[i, "Property Country"])), "Spread"].tolist()
    if len(propertylocationratelist) != 0:
        otherfixfactorbasedrate += propertylocationratelist[0]
    else:
        otherfixfactorbasedrate += 0.005

    tenantconditionratelist = tenantconditionratedata.loc[tenantconditionratedata["Condition"] == X_example.loc[i, "Tenant Condition"], "Spread"].tolist()
    if len(tenantconditionratelist) != 0:
        otherfixfactorbasedrate += tenantconditionratelist[0]

    propertytyperatelist = propertytyperatedata.loc[((propertytyperatedata["PropertyType"] == X_example.loc[i, "Property Type"]) & (propertytyperatedata["Country"] == X_example.loc[i, "Property Country"]) & (propertytyperatedata["No of Bedrooms"] == X_example.loc[i, "No of Bedrooms"])), "Spread"].tolist()
    if len(propertytyperatelist) != 0:
        otherfixfactorbasedrate += propertytyperatelist[0]

    occupationratelist = occupationratedata.loc[occupationratedata["Employment"] == X_example.loc[i, "Employment Type"], "Spread"].tolist()
    if len(occupationratelist) != 0:
        otherfixfactorbasedrate += occupationratelist[0]

    propertyconditionlist = propertyconditiondata.loc[propertyconditiondata["Property Condition"] == X_example.loc[i, "Property Condition"], "Spread"].tolist()
    if len(propertyconditionlist) != 0:
        otherfixfactorbasedrate += propertyconditionlist[0]

    if(X_example.loc[i, "Other Bank Loan Approval"] == 1):
        otherfixfactorbasedrate += otherfactorratedata["BankLoanApproval"]

    if(X_example.loc[i, "ESG Compliance"] == 1):
        otherfixfactorbasedrate += otherfactorratedata["ESG"]

    if(X_example.loc[i, "Company Applicant"] == 1):
        otherfixfactorbasedrate += otherfactorratedata["Company"]

    X_example.loc[i, "OtherFixFactorBasedRate"] = otherfixfactorbasedrate
    print(X_example)

X_test = np.array(X_example[["LVR", "Property Value", "TotalAnnualCommitmentsRatio", "TotalAnnualIncomeRatio", "ProposedAnnualRentRatio", "PropertyAssetsRatio", "NonPropertyAssetsRatio", "TotalLiabilitiesRatio", "Second Mortgage Flag", "BaseRate", "LendingCCYBasedRate", "OtherFixFactorBasedRate"]])
scaler_test = joblib.load(scalerfilename)
X_test = scaler_test.transform(X_test.astype(float))

model = load_model(modelfile)
Y_test = model.predict(X_test, verbose = 0)

print("Mortgage Rate Recommendation:")

for i in range(len(X_example)):
    LVR = X_example.loc[i, "LVR"]
    InterestRate = Y_test[i][0]

    dsr = (float(X_example.loc[i, "TotalAnnualCommitmentsRatio"]) + LVR * InterestRate) / (float(X_example.loc[i, "TotalAnnualIncomeRatio"]) + float(X_example.loc[i, "ProposedAnnualRentRatio"]))
    icr = float(X_example.loc[i, "ProposedAnnualRentRatio"]) / (LVR * InterestRate)
    nar = ((1 - LVR) + X_example.loc[i, "PropertyAssetsRatio"] + X_example.loc[i, "NonPropertyAssetsRatio"] - X_example.loc[i, "TotalLiabilitiesRatio"]) / LVR

    titeratio = (X_example.loc[i, "TotalAnnualIncomeRatio"] + X_example.loc[i, "ProposedAnnualRentRatio"]) / (X_example.loc[i, "TotalAnnualCommitmentsRatio"] + LVR * InterestRate)
    nalaratio = LVR / (X_example.loc[i, "PropertyAssetsRatio"] + X_example.loc[i, "NonPropertyAssetsRatio"] - X_example.loc[i, "TotalLiabilitiesRatio"])
    na24iratio = (X_example.loc[i, "PropertyAssetsRatio"] + X_example.loc[i, "NonPropertyAssetsRatio"] - X_example.loc[i, "TotalLiabilitiesRatio"]) / (LVR * InterestRate)
    fa24iratio = (X_example.loc[i, "NonPropertyAssetsRatio"] - X_example.loc[i, "TotalLiabilitiesRatio"]) / (LVR * InterestRate)

    if titeratio > 3:
        titescore = 5
    elif titeratio > 2:
        titescore = 4
    elif titeratio > 1.5:
        titescore = 3
    elif titeratio > 1.25:
        titescore = 2
    elif titeratio > 1:
        titescore = 1
    else:
        titescore = 0

    if nalaratio > 1:
        nalascore = 5
    elif nalaratio > 0.75:
        nalascore = 4
    elif nalaratio > 0.5:
        nalascore = 3
    elif nalaratio > 0.25:
        nalascore = 2
    elif nalaratio > 0:
        nalascore = 1
    else:
        nalascore = 0

    if na24iratio > 25:
        na24iscore = 5
    elif na24iratio > 15:
        na24iscore = 4
    elif na24iratio > 10:
        na24iscore = 3
    elif na24iratio > 5:
        na24iscore = 2
    elif na24iratio > 2:
        na24iscore = 1
    else:
        na24iscore = 0

    if fa24iratio > 10:
        fa24iscore = 5
    elif fa24iratio > 5:
        fa24iscore = 4
    elif fa24iratio > 2:
        fa24iscore = 3
    elif fa24iratio > 1:
        fa24iscore = 2
    elif fa24iratio > 0:
        fa24iscore = 1
    else:
        fa24iscore = 0

    financialscore = (titescore + nalascore + na24iscore + fa24iscore) / 4.0

    #print("=================================")

    print("LVR: " + "{:.0%}".format(LVR) + " | Interest Rate: " + "{:.1%}".format(InterestRate))

    #print("DSR:", "{:.2f}".format(dsr))
    #print("ICR:", "{:.2f}".format(icr))
    #print("NAR:", "{:.2f}".format(nar))
    #print("Financial Score:", "{:.2f}".format(financialscore))
    #if financialscore <= 1:
    #    print("Financial Score is less than or equal to 1.")

    #if dsr >= 0.8 and icr < 1.3 and nar < 2:
    #    print("Ratios are not good enough.")
    #print("=================================")
