import numpy as np
import pandas as pd

from sklearn.preprocessing import MinMaxScaler, StandardScaler, LabelEncoder
import joblib

from keras.models import Sequential, load_model
from keras.layers import *
from keras.utils.np_utils import to_categorical
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint, CSVLogger

matrixfile = "resultline_new.csv"
modelfile = "propcap_model.h5"
scalerfilename = "scaler.save"

trainingdata = pd.read_csv(matrixfile, header = 0)

X_data = trainingdata[["LVR", "PropertyValue", "TotalAnnualCommitmentsRatio", "TotalAnnualIncomeRatio", "ProposedAnnuelRentRatio", "PropertyAssetsRatio", "NonPropertyAssetsRatio", "TotalLiabilitiesRatio", "SecondMortgageFlag", "BaseRate", "LendingCCYBasedRate", "OtherFixFactorBasedRate"]]
Y_data = trainingdata["InterestRate"]

X_full = np.array(X_data)
scaler_full = MinMaxScaler()
scaler_full.fit(X_full.astype(float))
joblib.dump(scaler_full, scalerfilename)

X_full = scaler_full.transform(X_full.astype(float))
Y_full = np.array(Y_data)

featuresno = X_full.shape[1]
#outputno = Y_full.shape[1]
outputno = 1

model = Sequential()
model.add(Dense(featuresno, input_dim = featuresno, activation = "relu"))
model.add(Dense(featuresno, activation = "relu"))
model.add(Dense(featuresno, activation = "relu"))
model.add(Dense(featuresno, activation = "relu"))
model.add(Dense(featuresno, activation = "relu"))
model.add(Dense(featuresno, activation = "relu"))

model.add(Dense(outputno))

early_stopping =  EarlyStopping(monitor = "val_loss", min_delta = 0.0, patience = 10)
model.compile(loss ="mean_absolute_error", optimizer = "Adamax")

model.fit(X_full, Y_full, verbose = 1, epochs = 300, batch_size = 1024, validation_split = 0.2, shuffle = True, callbacks = [early_stopping])
#model.fit(X_full, Y_full, verbose = 1, epochs = 200, batch_size = 1024, validation_split = 0.2, shuffle = True)

model.save(modelfile)

#evaluate_error = model.evaluate(X_full, Y_full, verbose = 1)
#print(evaluate_error)

Y_test = model.predict(X_full, verbose = 1)
testdata = pd.DataFrame(Y_test, columns = ["InterestRatePredict"])

print(testdata)

fulldata = pd.concat([trainingdata, testdata], axis = 1)
#print(fulldata[["LVRPredict", "InterestRatePredict", "LVR", "InterestRate"]])
print(fulldata[["BaseRate", "InterestRatePredict", "InterestRate"]])

fulldata["dsr"] = (fulldata["TotalAnnualCommitmentsRatio"] + fulldata["LVR"] * fulldata["InterestRate"]) / (fulldata["TotalAnnualIncomeRatio"] + fulldata["ProposedAnnuelRentRatio"])
fulldata["icr"] = (fulldata["ProposedAnnuelRentRatio"]) / (fulldata["LVR"] * fulldata["InterestRate"])
fulldata["nar"] = ((1 - fulldata["LVR"]) + fulldata["PropertyAssetsRatio"] + fulldata["NonPropertyAssetsRatio"] - fulldata["TotalLiabilitiesRatio"]) / fulldata["LVR"]

fulldata["predictdsr"] = (fulldata["TotalAnnualCommitmentsRatio"] + fulldata["LVR"] * fulldata["InterestRatePredict"]) / (fulldata["TotalAnnualIncomeRatio"] + fulldata["ProposedAnnuelRentRatio"])
fulldata["predicticr"] = (fulldata["ProposedAnnuelRentRatio"]) / (fulldata["LVR"] * fulldata["InterestRatePredict"])
fulldata["predictnar"] = ((1 - fulldata["LVR"]) + fulldata["PropertyAssetsRatio"] + fulldata["NonPropertyAssetsRatio"] - fulldata["TotalLiabilitiesRatio"]) / fulldata["LVR"]

print(fulldata[["dsr", "icr", "nar", "predictdsr", "predicticr", "predictnar"]])
#fulldata.to_csv("fulldata.csv")
